import { createClient } from '@supabase/supabase-js'

const supabaseUrl = 'https://myquueookmjllqhpolfa.supabase.co'
const supabaseKey = 'sb_publishable_9KhrfHOaIz2e7KVyVehrTA_t4GLqYiz'

export const supabase = createClient(supabaseUrl, supabaseKey)
