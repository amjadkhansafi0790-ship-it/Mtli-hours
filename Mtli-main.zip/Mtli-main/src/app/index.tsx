import * as FileSystem from "expo-file-system/legacy";
import * as Sharing from "expo-sharing";
import React, { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator, Alert, Animated, Image, Modal, ScrollView,
  StyleSheet, Text, TextInput, TouchableOpacity, View
} from "react-native";
import { supabase } from "../supabase";
import TimesheetForm from "./TimesheetForm";

type Role = "employee" | "supervisor" | "manager";
type Status = "pending" | "approved" | "rejected";

interface Profile {
  id: string;
  full_name: string;
  job_title: string;
  phone: string;
  role: Role;
  country: string;
  province_state: string;
}

interface Timesheet {
  id: string;
  employee_id: string;
  employee_name: string;
  job_title: string;
  project: string;
  client: string;
  job_location: string;
  date: string;
  day: string;
  start_time: string;
  end_time: string;
  lunch_break: number;
  hours_worked: number;
  overtime_hours: number;
  work_description: string;
  period_start: string;
  period_end: string;
  status: Status;
  country: string;
}

const JOB_TITLES = ["Supervisor", "Project Manager", "Installer", "Other"];

const CANADA_PROVINCES = [
  "Alberta", "British Columbia", "Manitoba", "New Brunswick",
  "Newfoundland and Labrador", "Northwest Territories", "Nova Scotia",
  "Nunavut", "Ontario", "Prince Edward Island", "Quebec",
  "Saskatchewan", "Yukon"
];

const US_STATES = [
  "Alabama", "Alaska", "Arizona", "Arkansas", "California", "Colorado",
  "Connecticut", "Delaware", "Florida", "Georgia", "Hawaii", "Idaho",
  "Illinois", "Indiana", "Iowa", "Kansas", "Kentucky", "Louisiana",
  "Maine", "Maryland", "Massachusetts", "Michigan", "Minnesota",
  "Mississippi", "Missouri", "Montana", "Nebraska", "Nevada",
  "New Hampshire", "New Jersey", "New Mexico", "New York",
  "North Carolina", "North Dakota", "Ohio", "Oklahoma", "Oregon",
  "Pennsylvania", "Rhode Island", "South Carolina", "South Dakota",
  "Tennessee", "Texas", "Utah", "Vermont", "Virginia", "Washington",
  "West Virginia", "Wisconsin", "Wyoming"
];

const sColor = (s: Status) => ({ pending: "#f59e0b", approved: "#22c55e", rejected: "#ef4444" }[s]);
const sBg = (s: Status) => ({ pending: "#fef9c3", approved: "#dcfce7", rejected: "#fee2e2" }[s]);

function DropdownPicker({ label, options, value, onSelect, placeholder }: {
  label: string; options: string[]; value: string;
  onSelect: (v: string) => void; placeholder: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <View style={{ marginBottom: 16 }}>
      {label ? <Text style={s.label}>{label}</Text> : null}
      <TouchableOpacity style={s.dropBtn} onPress={() => setOpen(!open)}>
        <Text style={{ color: value ? "#1a1a1a" : "#c4c4c4", fontSize: 15 }}>{value || placeholder}</Text>
        <Text style={{ color: "#6b7280" }}>{open ? "▲" : "▼"}</Text>
      </TouchableOpacity>
      {open ? (
        <View style={s.dropList}>
          <ScrollView style={{ maxHeight: 200 }} nestedScrollEnabled={true} keyboardShouldPersistTaps="handled">
            {options.map((opt) => (
              <TouchableOpacity key={opt} style={[s.dropItem, value === opt && s.dropItemActive]} onPress={() => { onSelect(opt); setOpen(false); }}>
                <Text style={{ color: value === opt ? "#c1622a" : "#1a1a1a", fontSize: 14 }}>{opt}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      ) : null}
    </View>
  );
}


function MTLIClock() {
  const hourAnim = useRef(new Animated.Value(0)).current;
  const minuteAnim = useRef(new Animated.Value(0)).current;
  const secondAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    const updateClock = () => {
      const now = new Date();
      const hours = now.getHours() % 12;
      const minutes = now.getMinutes();
      const seconds = now.getSeconds();
      hourAnim.setValue((hours * 30) + (minutes * 0.5));
      minuteAnim.setValue(minutes * 6);
      secondAnim.setValue(seconds * 6);
    };
    updateClock();
    const interval = setInterval(updateClock, 1000);
    return () => clearInterval(interval);
  }, []);

  const hourRotate = hourAnim.interpolate({ inputRange: [0, 360], outputRange: ["0deg", "360deg"] });
  const minuteRotate = minuteAnim.interpolate({ inputRange: [0, 360], outputRange: ["0deg", "360deg"] });
  const secondRotate = secondAnim.interpolate({ inputRange: [0, 360], outputRange: ["0deg", "360deg"] });

  const SIZE = 180;
  const CENTER = SIZE / 2;
  const RADIUS = SIZE / 2 - 16;

  const clockNumbers = [12, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map((num, i) => {
    const angle = (i * 30 - 90) * (Math.PI / 180);
    const x = CENTER + RADIUS * Math.cos(angle) - 10;
    const y = CENTER + RADIUS * Math.sin(angle) - 10;
    return { num, x, y };
  });

  return (
    <View style={{ width: SIZE, height: SIZE, marginTop: 32, marginBottom: 8, alignItems: "center", justifyContent: "center" }}>
      <View style={{ width: SIZE, height: SIZE, borderRadius: SIZE / 2, backgroundColor: "#fff", borderWidth: 3, borderColor: "#c1622a", alignItems: "center", justifyContent: "center", position: "absolute", shadowColor: "#c1622a", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.2, shadowRadius: 8, elevation: 8 }} />
      
      {clockNumbers.map(({ num, x, y }) => (
        <View key={num} style={{ position: "absolute", left: x, top: y, width: 20, height: 20, alignItems: "center", justifyContent: "center" }}>
          <Text style={{ fontSize: 11, fontWeight: "700", color: "#1a1a1a" }}>{num}</Text>
        </View>
      ))}

      <Image
        source={require("../../assets/images/mtli-logo.png")}
        style={{ width: 80, height: 40, resizeMode: "contain", position: "absolute" }}
      />

      <Animated.View
        style={{
          position: "absolute",
          width: 0, height: 0,
          top: CENTER, left: CENTER,
          transform: [{ rotate: hourRotate }],
        }}
      >
        <View style={{
          position: "absolute",
          width: 3, height: 32,
          backgroundColor: "#1a1a1a", borderRadius: 2,
          left: -1.5, top: -32,
        }} />
      </Animated.View>

      <Animated.View
        style={{
          position: "absolute",
          width: 0, height: 0,
          top: CENTER, left: CENTER,
          transform: [{ rotate: minuteRotate }],
        }}
      >
        <View style={{
          position: "absolute",
          width: 2, height: 42,
          backgroundColor: "#c1622a", borderRadius: 2,
          left: -1, top: -42,
        }} />
      </Animated.View>

      <Animated.View
        style={{
          position: "absolute",
          width: 0, height: 0,
          top: CENTER, left: CENTER,
          transform: [{ rotate: secondRotate }],
        }}
      >
        <View style={{
          position: "absolute",
          width: 1, height: 46,
          backgroundColor: "#ff4444", borderRadius: 1,
          left: -0.5, top: -46,
        }} />
      </Animated.View>

      <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: "#c1622a", position: "absolute" }} />
    </View>
  );
}

export default function App() {
  const [screen, setScreen] = useState<"login" | "register" | "employee" | "supervisor" | "manager" | "super_admin">("login");
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(false);
  const [timesheets, setTimesheets] = useState<Timesheet[]>([]);
  const [showForm, setShowForm] = useState(false);

  React.useEffect(() => {
    supabase.auth.getSession().then(async ({ data: { session } }) => {
      if (session) {
        const { data: prof } = await supabase.from("profiles").select("*").eq("id", session.user.id).single();
        if (prof) {
          setProfile(prof);
          setScreen(prof.role as any);
          if (prof.role === "manager" || prof.role === "super_admin") loadAll();
          else loadMine(session.user.id);
          if (prof.role === "super_admin") loadUsers();
        }
      }
    });
  }, []);

  const [phone, setPhone] = useState("");
  const [isManagerLogin, setIsManagerLogin] = useState(false);
  const [loginEmail, setLoginEmail] = useState("");
  const [password, setPassword] = useState("");

  const [regName, setRegName] = useState("");
  const [regJobTitle, setRegJobTitle] = useState("");
  const [regCustomTitle, setRegCustomTitle] = useState("");
  const [regPhone, setRegPhone] = useState("");
  const [regPassword, setRegPassword] = useState("");
  const [regRole, setRegRole] = useState<Role>("employee");
  const [regEmail, setRegEmail] = useState("");
  const [regCountry, setRegCountry] = useState("Canada");
  const [regProvince, setRegProvince] = useState("");

  const [filterStatus, setFilterStatus] = useState("all");
  const [users, setUsers] = useState<any[]>([]);
  const [usersLoading, setUsersLoading] = useState(false);
  const [searchText, setSearchText] = useState("");
  const [editModal, setEditModal] = useState(false);
  const [editItem, setEditItem] = useState<Timesheet | null>(null);

  const provinces = regCountry === "Canada" ? CANADA_PROVINCES : US_STATES;
  const finalTitle = regJobTitle === "Other" ? regCustomTitle : regJobTitle;

  const handleLogin = async () => {
    if (isManagerLogin && !loginEmail) { Alert.alert("Error", "Please enter your email or username"); return; }
    if (!isManagerLogin && !phone) { Alert.alert("Error", "Please enter your phone number"); return; }
    if (!password) { Alert.alert("Error", "Please enter your password"); return; }
    setLoading(true);
    const email = isManagerLogin ? loginEmail : `${phone.replace(/\D/g, "")}@mtlihours.com`;
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) { Alert.alert("Login Failed", "Wrong phone or password"); setLoading(false); return; }
    const { data: prof } = await supabase.from("profiles").select("*").eq("id", data.user.id).single();
    if (!prof) { Alert.alert("Error", "Profile not found. Please register again."); setLoading(false); return; }
    setProfile(prof);
    setScreen(prof.role as any);
    if (prof.role !== "manager") loadMine(data.user.id);
    else loadAll();
    setLoading(false);
  };

  const handleRegister = async () => {
    if (!regPassword) { Alert.alert("Error", "Please enter your password"); return; }
    if (regRole === "manager" && !regEmail) { Alert.alert("Error", "Please enter your email"); return; }
    if (regRole !== "manager" && !regPhone) { Alert.alert("Error", "Please enter your phone number"); return; }
    setLoading(true);
    const email = regRole === "manager" ? regEmail : `${regPhone.replace(/\D/g, "")}@mtlihours.com`;
    const { data, error } = await supabase.auth.signUp({ email, password: regPassword });
    if (error) { Alert.alert("Registration Failed", error.message); setLoading(false); return; }
    await supabase.from("profiles").insert({
      id: data.user!.id, full_name: regName, job_title: finalTitle,
      phone: regPhone, role: regRole, country: regCountry, province_state: regProvince
    });
    Alert.alert("Success!", "Account created! Please sign in.");
    setScreen("login");
    setLoading(false);
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    setProfile(null); setScreen("login"); setPhone(""); setPassword("");
    setShowForm(false);
  };

  const loadMine = async (uid: string) => {
    const { data } = await supabase.from("timesheets").select("*").eq("employee_id", uid).order("date", { ascending: false });
    setTimesheets(data || []);
  };

  const formatTime12 = (time: string): string => {
    if (!time) return "";
    const [h, m] = time.split(":").map(Number);
    const ampm = h >= 12 ? "PM" : "AM";
    const hour = h % 12 || 12;
    return `${hour}:${String(m).padStart(2, "0")} ${ampm}`;
  };

    const downloadExcel = async (data: Timesheet[], filename: string) => {
    try {
      const headers = ["Employee Name","Job Title","Date","Day","Start Time","End Time","Hours Worked","Overtime","Lunch Break","Project","Client","Job Location","Work Description","Period Start","Period End","Status","Country","Total Hours (Employee)"];
      const employeeTotals: { [key: string]: { total: number; displayName: string } } = {};
      data.forEach(h => {
        const key = (h.employee_name || "").toLowerCase().trim();
        if (!employeeTotals[key]) employeeTotals[key] = { total: 0, displayName: h.employee_name };
        employeeTotals[key].total += (h.hours_worked || 0);
      });
      const rows = data.map(h => [
        h.employee_name || "", h.job_title || "", h.date || "", h.day || "",
        formatTime12(h.start_time || ""), formatTime12(h.end_time || ""),
        String(h.hours_worked || 0), String(h.overtime_hours || 0),
        h.lunch_break === 0 ? "No Lunch" : `${h.lunch_break} min`,
        h.project || "", h.client || "", h.job_location || "",
        h.work_description || "", h.period_start || "", h.period_end || "",
        h.status || "", h.country || "",
        String((employeeTotals[(h.employee_name || "").toLowerCase().trim()]?.total || 0).toFixed(2)) + "h"
      ]);
      const summaryRows = Object.entries(employeeTotals).map(([key, { total, displayName }]) => [
        displayName, "", "", "", "", "TOTAL:", String(total.toFixed(2)) + "h", "", "", "", "", "", "", "", "", "", "", ""
      ]);
      const allRows = [...rows, ["","","","","","","","","","","","","","","","","",""], ...summaryRows];
      const csv = [headers, ...allRows].map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(",")).join("\n");
      const csvFilename = filename.replace(".xlsx", ".csv");

      if (typeof document !== "undefined") {
        const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = csvFilename;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(url);
      } else {
        const uri = FileSystem.documentDirectory + csvFilename;
        await FileSystem.writeAsStringAsync(uri, csv, { encoding: "utf8" });
        await Sharing.shareAsync(uri, { mimeType: "text/csv", dialogTitle: "Download Hours Report" });
      }
    } catch (e) {
      Alert.alert("Error", "Failed to download file: " + String(e));
    }
  };


  const downloadPDF = async (data: Timesheet[], filename: string) => {
    try {
      const rows = data.map(h => `
        <tr>
          <td>${h.employee_name}</td>
          <td>${h.job_title}</td>
          <td>${h.date}</td>
          <td>${h.day}</td>
          <td>${h.start_time}</td>
          <td>${h.end_time}</td>
          <td>${h.hours_worked}h</td>
          <td>${h.overtime_hours}h</td>
          <td>${h.project || ""}</td>
          <td>${h.client || ""}</td>
          <td>${h.job_location || ""}</td>
          <td>${h.status}</td>
        </tr>
      `).join("");

      const html = `
        <html>
        <head>
          <style>
            body { font-family: Arial; padding: 20px; }
            h1 { color: #4f46e5; }
            table { width: 100%; border-collapse: collapse; font-size: 11px; }
            th { background: #4f46e5; color: white; padding: 8px; text-align: left; }
            td { padding: 6px 8px; border-bottom: 1px solid #e5e7eb; }
            tr:nth-child(even) { background: #f9fafb; }
          </style>
        </head>
        <body>
          <h1>MTLI Group of Companies</h1>
          <h2>Hours Report</h2>
          <p>Generated: ${new Date().toLocaleDateString()}</p>
          <table>
            <thead>
              <tr>
                <th>Name</th><th>Title</th><th>Date</th><th>Day</th>
                <th>Start</th><th>End</th><th>Hours</th><th>OT</th>
                <th>Project</th><th>Client</th><th>Location</th><th>Status</th>
              </tr>
            </thead>
            <tbody>${rows}</tbody>
          </table>
        </body>
        </html>
      `;

      const uri = FileSystem.documentDirectory + filename.replace(".pdf", ".html");
      await FileSystem.writeAsStringAsync(uri, html, { encoding: "utf8" });
      await Sharing.shareAsync(uri);
    } catch (e) {
      Alert.alert("Error", "Failed to download PDF file.");
    }
  };

  const loadUsers = async () => {
    setUsersLoading(true);
    const { data } = await supabase.from("profiles").select("*").order("full_name");
    setUsers(data || []);
    setUsersLoading(false);
  };

  const updateUserRole = async (userId: string, newRole: string) => {
    await supabase.from("profiles").update({ role: newRole }).eq("id", userId);
    loadUsers();
    Alert.alert("Updated!", `Role changed to ${newRole}`);
  };

  const toggleUserActive = async (userId: string, isActive: boolean) => {
    await supabase.from("profiles").update({ is_active: !isActive }).eq("id", userId);
    loadUsers();
    Alert.alert(!isActive ? "Activated!" : "Deactivated!", "User status updated.");
  };

  const loadAll = async () => {
    const { data } = await supabase.from("timesheets").select("*").order("date", { ascending: false });
    setTimesheets(data || []);
  };

  const handleSubmitTimesheet = async (formData: any) => {
    const { error } = await supabase.from("timesheets").insert({ ...formData, submitted_by: profile!.id });
    if (error) { Alert.alert("Error", "Failed to submit."); }
    else {
      Alert.alert("Success!", "Hours submitted!");
      setShowForm(false);
      loadMine(profile!.id);
    }
  };

  const updateStatus = async (id: string, status: Status) => {
    await supabase.from("timesheets").update({ status }).eq("id", id);
    loadAll();
  };

  const saveEdit = async () => {
    if (!editItem) return;
    await supabase.from("timesheets").update({
      employee_name: editItem.employee_name,
      job_title: editItem.job_title,
      date: editItem.date,
      start_time: editItem.start_time,
      end_time: editItem.end_time,
      hours_worked: editItem.hours_worked,
      overtime_hours: editItem.overtime_hours,
      project: editItem.project,
      client: editItem.client,
      job_location: editItem.job_location,
      work_description: editItem.work_description,
      period_start: editItem.period_start,
      period_end: editItem.period_end,
    }).eq("id", editItem.id);
    setEditModal(false); loadAll();
    Alert.alert("Saved!", "Timesheet updated.");
  };

  const filtered = timesheets.filter((h) => {
    const ms = filterStatus === "all" || h.status === filterStatus;
    const mt = !searchText ||
      h.employee_name?.toLowerCase().includes(searchText.toLowerCase()) ||
      h.project?.toLowerCase().includes(searchText.toLowerCase()) ||
      h.client?.toLowerCase().includes(searchText.toLowerCase());
    return ms && mt;
  });

  const Header = ({ role, name, job }: { role: string; name: string; job?: string }) => (
    <View style={s.header}>
      <View>
        <Text style={s.headerSub}>{role}</Text>
        <Text style={s.headerTitle}>{name}</Text>
        {job ? <Text style={s.headerJob}>{job}</Text> : null}
      </View>
      <TouchableOpacity style={s.signOutBtn} onPress={handleSignOut}>
        <Text style={s.signOutText}>Sign out</Text>
      </TouchableOpacity>
    </View>
  );

  if (screen === "login") {
    return (
      <View style={s.container}>
        <View style={s.inner}>
          <ScrollView contentContainerStyle={s.center} keyboardShouldPersistTaps="handled">
            <MTLIClock />
            <Text style={s.appName}>MTLI Hours</Text>
            <Text style={s.appSub}>Group of Companies</Text>
            <View style={s.card}>
              <View style={[s.row, { marginBottom: 16 }]}>
                <TouchableOpacity style={[s.roleBtn, !isManagerLogin && s.roleBtnActive]} onPress={() => setIsManagerLogin(false)}>
                  <Text style={[s.roleBtnText, !isManagerLogin && s.roleBtnTextActive]}>Employee</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[s.roleBtn, isManagerLogin && s.roleBtnActive]} onPress={() => setIsManagerLogin(true)}>
                  <Text style={[s.roleBtnText, isManagerLogin && s.roleBtnTextActive]}>Manager</Text>
                </TouchableOpacity>
              </View>

              {isManagerLogin ? (
                <View>
                  <Text style={s.label}>EMAIL OR USERNAME</Text>
                  <TextInput style={s.input} placeholderTextColor="#c4c4c4" placeholder="Enter email or username" keyboardType="email-address" autoCapitalize="none" value={loginEmail} onChangeText={setLoginEmail} />
                </View>
              ) : (
                <View>
                  <Text style={s.label}>PHONE NUMBER</Text>
                  <TextInput style={s.input} placeholderTextColor="#c4c4c4" placeholder="e.g. 6041234567" keyboardType="phone-pad" value={phone} onChangeText={setPhone} />
                </View>
              )}

              <Text style={s.label}>PASSWORD</Text>
              <TextInput style={s.input} placeholderTextColor="#c4c4c4" placeholder="Password" secureTextEntry={true} value={password} onChangeText={setPassword} />
              <TouchableOpacity style={s.btn} onPress={handleLogin} disabled={loading}>
                {loading ? <ActivityIndicator color="#fff" /> : <Text style={s.btnText}>Sign In</Text>}
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setScreen("register")} style={{ marginTop: 16, alignItems: "center" }}>
                <Text style={{ color: "#c1622a", fontWeight: "600" }}>New employee? Register here</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </View>
    );
  }

  if (screen === "register") {
    return (
      <View style={s.container}>
        <View style={s.inner}>
          <ScrollView contentContainerStyle={s.center} keyboardShouldPersistTaps="handled">
            <MTLIClock />
            <Text style={s.appName}>Create Account</Text>
            <Text style={s.appSub}>MTLI Group of Companies</Text>
            <View style={s.card}>
              <Text style={s.label}>FULL NAME</Text>
              <TextInput style={s.input} placeholderTextColor="#c4c4c4" placeholder="Your full name" value={regName} onChangeText={setRegName} />

              <DropdownPicker label="JOB TITLE" options={JOB_TITLES} value={regJobTitle} onSelect={(v) => { setRegJobTitle(v); setRegCustomTitle(""); }} placeholder="Select job title..." />

              {regJobTitle === "Other" ? (
                <View>
                  <Text style={s.label}>YOUR JOB TITLE</Text>
                  <TextInput style={s.input} placeholderTextColor="#c4c4c4" placeholder="Type your job title" value={regCustomTitle} onChangeText={setRegCustomTitle} />
                </View>
              ) : null}

              {regRole === "manager" ? (
                <View>
                  <Text style={s.label}>EMAIL</Text>
                  <TextInput style={s.input} placeholderTextColor="#c4c4c4" placeholder="manager@mtli.com" keyboardType="email-address" value={regEmail} onChangeText={setRegEmail} autoCapitalize="none" />
                  <Text style={s.label}>USERNAME</Text>
                  <TextInput style={s.input} placeholderTextColor="#c4c4c4" placeholder="Username" value={regName} onChangeText={setRegName} autoCapitalize="none" />
                </View>
              ) : (
                <View>
                  <Text style={s.label}>PHONE NUMBER</Text>
                  <TextInput style={s.input} placeholderTextColor="#c4c4c4" placeholder="e.g. 6041234567" keyboardType="phone-pad" value={regPhone} onChangeText={setRegPhone} />
                </View>
              )}

              <Text style={s.label}>PASSWORD</Text>
              <TextInput style={s.input} placeholderTextColor="#c4c4c4" placeholder="Min 6 characters" secureTextEntry={true} value={regPassword} onChangeText={setRegPassword} />

              <Text style={s.label}>ROLE</Text>
              <View style={[s.row, { marginBottom: 16 }]}>
                {(["employee", "supervisor", "manager"] as Role[]).map((r) => (
                  <TouchableOpacity key={r} style={[s.roleBtn, regRole === r && s.roleBtnActive]} onPress={() => setRegRole(r)}>
                    <Text style={[s.roleBtnText, regRole === r && s.roleBtnTextActive]}>{r === "employee" ? "Employee" : r === "supervisor" ? "Supervisor" : "Manager"}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={s.label}>COUNTRY</Text>
              <View style={[s.row, { marginBottom: 16 }]}>
                {["Canada", "USA"].map((c) => (
                  <TouchableOpacity key={c} style={[s.roleBtn, regCountry === c && s.roleBtnActive]} onPress={() => { setRegCountry(c); setRegProvince(""); }}>
                    <Text style={[s.roleBtnText, regCountry === c && s.roleBtnTextActive]}>{c === "Canada" ? "🇨🇦 Canada" : "🇺🇸 USA"}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              <DropdownPicker
                label={regCountry === "Canada" ? "PROVINCE / TERRITORY" : "STATE"}
                options={provinces}
                value={regProvince}
                onSelect={setRegProvince}
                placeholder={regCountry === "Canada" ? "Select province..." : "Select state..."}
              />

              <TouchableOpacity style={s.btn} onPress={handleRegister} disabled={loading}>
                {loading ? <ActivityIndicator color="#fff" /> : <Text style={s.btnText}>Create Account</Text>}
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setScreen("login")} style={{ marginTop: 16, alignItems: "center" }}>
                <Text style={{ color: "#c1622a", fontWeight: "600" }}>Already have an account? Sign in</Text>
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </View>
    );
  }

  if (screen === "employee") {
    return (
      <View style={s.container}>
        <View style={s.inner}>
          <Header role="Employee" name={profile?.full_name || ""} job={profile?.job_title} />
          {showForm ? (
            <TimesheetForm
              isSupervisor={false}
              profileName={profile?.full_name || ""}
              profileTitle={profile?.job_title || ""}
              profileCountry={profile?.country || ""}
              profileId={profile?.id || ""}
              onSubmit={handleSubmitTimesheet}
              onCancel={() => setShowForm(false)}
            />
          ) : (
            <ScrollView contentContainerStyle={{ padding: 16 }} keyboardShouldPersistTaps="handled">
              <TouchableOpacity style={s.btn} onPress={() => setShowForm(true)}>
                <Text style={s.btnText}>+ Submit Today's Hours</Text>
              </TouchableOpacity>
              <View style={[s.card, { marginTop: 16 }]}>
                <Text style={s.cardTitle}>My Submissions</Text>
                {timesheets.length === 0 ? (
                  <Text style={{ color: "#6b7280", textAlign: "center" }}>No submissions yet</Text>
                ) : (
                  timesheets.map((h) => (
                    <View key={h.id} style={s.entryRow}>
                      <View style={{ flex: 1 }}>
                        <Text style={s.entryDate}>{h.date} - {h.day}</Text>
                        <Text style={s.entrySub}>{formatTime12(h.start_time)} to {formatTime12(h.end_time)} - {h.hours_worked}h</Text>
                        {h.overtime_hours > 0 ? <Text style={{ color: "#dc2626", fontSize: 12 }}>OT: {h.overtime_hours}h</Text> : null}
                        {h.project ? <Text style={s.entryMeta}>{h.project} {h.client ? `- ${h.client}` : ""}</Text> : null}
                        {h.job_location ? <Text style={s.entryMeta}>{h.job_location}</Text> : null}
                      </View>
                      <View style={[s.badge, { backgroundColor: sBg(h.status) }]}>
                        <Text style={[s.badgeText, { color: sColor(h.status) }]}>{h.status}</Text>
                      </View>
                    </View>
                  ))
                )}
              </View>
            </ScrollView>
          )}
        </View>
      </View>
    );
  }

  if (screen === "supervisor") {
    return (
      <View style={s.container}>
        <View style={s.inner}>
          <Header role="Supervisor" name={profile?.full_name || ""} job={profile?.job_title} />
          {showForm ? (
            <TimesheetForm
              isSupervisor={true}
              profileName={profile?.full_name || ""}
              profileTitle={profile?.job_title || ""}
              profileCountry={profile?.country || ""}
              profileId={profile?.id || ""}
              onSubmit={handleSubmitTimesheet}
              onCancel={() => setShowForm(false)}
            />
          ) : (
            <ScrollView contentContainerStyle={{ padding: 16 }} keyboardShouldPersistTaps="handled">
              <View style={s.row}>
                <TouchableOpacity style={[s.btn, { flex: 1, marginRight: 8 }]} onPress={() => setShowForm(true)}>
                  <Text style={s.btnText}>Submit for Team</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[s.btn, { flex: 1, marginLeft: 8, backgroundColor: "#8b3d0f" }]} onPress={() => setShowForm(true)}>
                  <Text style={s.btnText}>My Hours</Text>
                </TouchableOpacity>
              </View>
              <View style={s.card}>
                <Text style={s.cardTitle}>Recent Submissions</Text>
                {timesheets.length === 0 ? (
                  <Text style={{ color: "#6b7280", textAlign: "center" }}>No submissions yet</Text>
                ) : (
                  timesheets.map((h) => (
                    <View key={h.id} style={s.entryRow}>
                      <View style={{ flex: 1 }}>
                        <Text style={s.entryName}>{h.employee_name}</Text>
                        <Text style={s.entryDate}>{h.date} - {h.day}</Text>
                        <Text style={s.entrySub}>{formatTime12(h.start_time)} to {formatTime12(h.end_time)} - {h.hours_worked}h</Text>
                        {h.overtime_hours > 0 ? <Text style={{ color: "#dc2626", fontSize: 12 }}>OT: {h.overtime_hours}h</Text> : null}
                        {h.project ? <Text style={s.entryMeta}>{h.project}</Text> : null}
                      </View>
                      <View style={[s.badge, { backgroundColor: sBg(h.status) }]}>
                        <Text style={[s.badgeText, { color: sColor(h.status) }]}>{h.status}</Text>
                      </View>
                    </View>
                  ))
                )}
              </View>
            </ScrollView>
          )}
        </View>
      </View>
    );
  }

  if (screen === "manager") {
    return (
      <View style={s.container}>
        <View style={s.inner}>
          <Header role="Manager Dashboard" name="Team Hours" />
          <ScrollView contentContainerStyle={{ padding: 16 }} keyboardShouldPersistTaps="handled">
            <View style={s.row}>
              {[
                { label: "Pending", count: timesheets.filter((h) => h.status === "pending").length, color: "#854d0e", bg: "#fef9c3" },
                { label: "Approved", count: timesheets.filter((h) => h.status === "approved").length, color: "#166534", bg: "#dcfce7" },
                { label: "Total", count: timesheets.length, color: "#8b3d0f", bg: "#fdf0e8" },
              ].map((stat) => (
                <View key={stat.label} style={[s.statBox, { backgroundColor: stat.bg }]}>
                  <Text style={[s.statNum, { color: stat.color }]}>{stat.count}</Text>
                  <Text style={[s.statLabel, { color: stat.color }]}>{stat.label}</Text>
                </View>
              ))}
            </View>

            <View style={s.row}>
              <TouchableOpacity style={[s.btn, { flex: 1, marginRight: 8, backgroundColor: "#16a34a" }]} onPress={() => downloadExcel(timesheets, "MTLI_Hours_All.xlsx")}>
                <Text style={s.btnText}>⬇ Excel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.btn, { flex: 1, marginLeft: 8, backgroundColor: "#dc2626" }]} onPress={() => downloadPDF(timesheets, "MTLI_Hours_All.pdf")}>
                <Text style={s.btnText}>⬇ PDF</Text>
              </TouchableOpacity>
            </View>

            <TextInput style={[s.input, { marginBottom: 12 }]} placeholderTextColor="#c4c4c4" placeholder="Search name, project, client..." value={searchText} onChangeText={setSearchText} />

            <ScrollView horizontal={true} showsHorizontalScrollIndicator={false} style={{ marginBottom: 16 }}>
              {["all", "pending", "approved", "rejected"].map((f) => (
                <TouchableOpacity key={f} style={[s.filterBtn, filterStatus === f && s.filterBtnActive]} onPress={() => setFilterStatus(f)}>
                  <Text style={[s.filterText, filterStatus === f && s.filterTextActive]}>{f.charAt(0).toUpperCase() + f.slice(1)}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>

            {filtered.map((h) => (
              <View key={h.id} style={s.card}>
                <View style={s.row}>
                  <View style={{ flex: 1 }}>
                    <Text style={s.entryName}>{h.employee_name}</Text>
                    <Text style={s.entrySub}>{h.job_title}</Text>
                    <Text style={s.entryDate}>{h.date} - {h.day}</Text>
                    <Text style={s.entrySub}>{formatTime12(h.start_time)} to {formatTime12(h.end_time)} - {h.hours_worked}h</Text>
                    {h.overtime_hours > 0 ? <Text style={{ color: "#dc2626", fontSize: 12, fontWeight: "600" }}>OT: {h.overtime_hours}h</Text> : null}
                    {h.project ? <Text style={s.entryMeta}>{h.project} {h.client ? `- ${h.client}` : ""}</Text> : null}
                    {h.job_location ? <Text style={s.entryMeta}>{h.job_location}</Text> : null}
                    {h.work_description ? <Text style={s.entryMeta}>{h.work_description}</Text> : null}
                  </View>
                  <View style={[s.badge, { backgroundColor: sBg(h.status) }]}>
                    <Text style={[s.badgeText, { color: sColor(h.status) }]}>{h.status}</Text>
                  </View>
                </View>
                <View style={[s.row, { marginTop: 12 }]}>
                  {h.status === "pending" ? (
                    <View style={[s.row, { flex: 1, marginBottom: 0 }]}>
                      <TouchableOpacity style={[s.btn, { flex: 1, marginRight: 6, backgroundColor: "#16a34a", padding: 10 }]} onPress={() => updateStatus(h.id, "approved")}>
                        <Text style={s.btnText}>Approve</Text>
                      </TouchableOpacity>
                      <TouchableOpacity style={[s.btn, { flex: 1, marginHorizontal: 6, backgroundColor: "#dc2626", padding: 10 }]} onPress={() => updateStatus(h.id, "rejected")}>
                        <Text style={s.btnText}>Reject</Text>
                      </TouchableOpacity>
                    </View>
                  ) : null}
                  <TouchableOpacity style={[s.btn, { backgroundColor: "#8b3d0f", padding: 10, marginLeft: 6 }]} onPress={() => { setEditItem(h); setEditModal(true); }}>
                    <Text style={s.btnText}>Edit</Text>
                  </TouchableOpacity>
                </View>
              </View>
            ))}
          </ScrollView>

          <Modal visible={editModal} animationType="slide" transparent={true}>
            <View style={s.modalOverlay}>
              <View style={s.modalCard}>
                <Text style={s.cardTitle}>Edit Timesheet</Text>
                {editItem ? (
                  <ScrollView keyboardShouldPersistTaps="handled">
                    <Text style={s.label}>EMPLOYEE NAME</Text>
                    <TextInput style={s.input} placeholderTextColor="#c4c4c4" value={editItem.employee_name} onChangeText={(t) => setEditItem({ ...editItem, employee_name: t })} />
                    <Text style={s.label}>JOB TITLE</Text>
                    <TextInput style={s.input} placeholderTextColor="#c4c4c4" value={editItem.job_title} onChangeText={(t) => setEditItem({ ...editItem, job_title: t })} />
                    <Text style={s.label}>DATE</Text>
                    <TextInput style={s.input} placeholderTextColor="#c4c4c4" value={editItem.date} onChangeText={(t) => setEditItem({ ...editItem, date: t })} />
                    <Text style={s.label}>START TIME</Text>
                    <TextInput style={s.input} placeholderTextColor="#c4c4c4" value={editItem.start_time} onChangeText={(t) => setEditItem({ ...editItem, start_time: t })} />
                    <Text style={s.label}>END TIME</Text>
                    <TextInput style={s.input} placeholderTextColor="#c4c4c4" value={editItem.end_time} onChangeText={(t) => setEditItem({ ...editItem, end_time: t })} />
                    <Text style={s.label}>HOURS WORKED</Text>
                    <TextInput style={s.input} placeholderTextColor="#c4c4c4" value={String(editItem.hours_worked)} keyboardType="numeric" onChangeText={(t) => setEditItem({ ...editItem, hours_worked: parseFloat(t) || 0 })} />
                    <Text style={s.label}>OVERTIME HOURS</Text>
                    <TextInput style={s.input} placeholderTextColor="#c4c4c4" value={String(editItem.overtime_hours)} keyboardType="numeric" onChangeText={(t) => setEditItem({ ...editItem, overtime_hours: parseFloat(t) || 0 })} />
                    <Text style={s.label}>PROJECT</Text>
                    <TextInput style={s.input} placeholderTextColor="#c4c4c4" value={editItem.project} onChangeText={(t) => setEditItem({ ...editItem, project: t })} />
                    <Text style={s.label}>CLIENT</Text>
                    <TextInput style={s.input} placeholderTextColor="#c4c4c4" value={editItem.client} onChangeText={(t) => setEditItem({ ...editItem, client: t })} />
                    <Text style={s.label}>JOB LOCATION</Text>
                    <TextInput style={s.input} placeholderTextColor="#c4c4c4" value={editItem.job_location} onChangeText={(t) => setEditItem({ ...editItem, job_location: t })} />
                    <Text style={s.label}>WORK DESCRIPTION</Text>
                    <TextInput style={[s.input, { height: 80 }]} placeholderTextColor="#c4c4c4" value={editItem.work_description} onChangeText={(t) => setEditItem({ ...editItem, work_description: t })} multiline={true} />
                    <Text style={s.label}>PERIOD START</Text>
                    <TextInput style={s.input} placeholderTextColor="#c4c4c4" value={editItem.period_start} onChangeText={(t) => setEditItem({ ...editItem, period_start: t })} />
                    <Text style={s.label}>PERIOD END</Text>
                    <TextInput style={s.input} placeholderTextColor="#c4c4c4" value={editItem.period_end} onChangeText={(t) => setEditItem({ ...editItem, period_end: t })} />
                    <TouchableOpacity style={s.btn} onPress={saveEdit}>
                      <Text style={s.btnText}>Save Changes</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={[s.btn, { backgroundColor: "#6b7280", marginTop: 8 }]} onPress={() => setEditModal(false)}>
                      <Text style={s.btnText}>Cancel</Text>
                    </TouchableOpacity>
                  </ScrollView>
                ) : null}
              </View>
            </View>
          </Modal>
        </View>
      </View>
    );
  }

  if (screen === "super_admin") {
    return (
      <View style={s.container}>
        <View style={s.inner}>
          <Header role="Super Admin" name="MTLI Control Panel" />
          <ScrollView contentContainerStyle={{ padding: 16 }} keyboardShouldPersistTaps="handled">
            <View style={s.row}>
              {[
                { label: "Users", count: users.length, color: "#8b3d0f", bg: "#fdf0e8" },
                { label: "Timesheets", count: timesheets.length, color: "#166534", bg: "#dcfce7" },
                { label: "Pending", count: timesheets.filter(h => h.status === "pending").length, color: "#854d0e", bg: "#fef9c3" },
              ].map((stat) => (
                <View key={stat.label} style={[s.statBox, { backgroundColor: stat.bg }]}>
                  <Text style={[s.statNum, { color: stat.color }]}>{stat.count}</Text>
                  <Text style={[s.statLabel, { color: stat.color }]}>{stat.label}</Text>
                </View>
              ))}
            </View>

            <View style={s.row}>
              <TouchableOpacity style={[s.btn, { flex: 1, marginRight: 8, backgroundColor: "#16a34a" }]} onPress={() => downloadExcel(timesheets, "MTLI_Hours_All.xlsx")}>
                <Text style={s.btnText}>⬇ Excel</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[s.btn, { flex: 1, marginLeft: 8, backgroundColor: "#dc2626" }]} onPress={() => downloadPDF(timesheets, "MTLI_Hours_All.pdf")}>
                <Text style={s.btnText}>⬇ PDF</Text>
              </TouchableOpacity>
            </View>

            <Text style={[s.cardTitle, { marginTop: 8 }]}>All Users</Text>
            {usersLoading ? <ActivityIndicator color="#c1622a" /> : users.map((u) => (
              <View key={u.id} style={s.card}>
                <View style={s.row}>
                  <View style={{ flex: 1 }}>
                    <Text style={s.entryName}>{u.full_name}</Text>
                    <Text style={s.entrySub}>{u.job_title} - {u.phone}</Text>
                    <Text style={s.entryMeta}>{u.country} - {u.province_state}</Text>
                  </View>
                  <View style={[s.badge, { backgroundColor: u.is_active === false ? "#fee2e2" : "#dcfce7" }]}>
                    <Text style={[s.badgeText, { color: u.is_active === false ? "#991b1b" : "#166534" }]}>{u.is_active === false ? "Inactive" : "Active"}</Text>
                  </View>
                </View>
                <Text style={[s.label, { marginTop: 8 }]}>ROLE: {u.role?.toUpperCase()}</Text>
                <ScrollView horizontal={true} showsHorizontalScrollIndicator={false} style={{ marginBottom: 8 }}>
                  {["employee", "supervisor", "manager", "super_admin"].map((r) => (
                    <TouchableOpacity key={r} style={[s.filterBtn, u.role === r && s.filterBtnActive, { marginRight: 6 }]} onPress={() => updateUserRole(u.id, r)}>
                      <Text style={[s.filterText, u.role === r && s.filterTextActive]}>{r}</Text>
                    </TouchableOpacity>
                  ))}
                </ScrollView>
                <TouchableOpacity style={[s.btn, { backgroundColor: u.is_active === false ? "#16a34a" : "#dc2626", padding: 10 }]} onPress={() => toggleUserActive(u.id, u.is_active !== false)}>
                  <Text style={s.btnText}>{u.is_active === false ? "Activate User" : "Deactivate User"}</Text>
                </TouchableOpacity>
              </View>
            ))}

            <Text style={[s.cardTitle, { marginTop: 8 }]}>All Timesheets</Text>
            <TextInput style={[s.input, { marginBottom: 12 }]} placeholderTextColor="#c4c4c4" placeholder="Search name, project, client..." value={searchText} onChangeText={setSearchText} />
            {timesheets.filter(h => !searchText || h.employee_name?.toLowerCase().includes(searchText.toLowerCase())).map((h) => (
              <View key={h.id} style={s.card}>
                <Text style={s.entryName}>{h.employee_name}</Text>
                <Text style={s.entryDate}>{h.date} - {h.day}</Text>
                <Text style={s.entrySub}>{formatTime12(h.start_time)} to {formatTime12(h.end_time)} - {h.hours_worked}h</Text>
                {h.overtime_hours > 0 ? <Text style={{ color: "#dc2626", fontSize: 12 }}>OT: {h.overtime_hours}h</Text> : null}
                {h.project ? <Text style={s.entryMeta}>{h.project} {h.client ? `- ${h.client}` : ""}</Text> : null}
                <View style={[s.badge, { backgroundColor: sBg(h.status), marginTop: 8 }]}>
                  <Text style={[s.badgeText, { color: sColor(h.status) }]}>{h.status}</Text>
                </View>
              </View>
            ))}
          </ScrollView>
        </View>
      </View>
    );
  }

  return null;
}

const s = StyleSheet.create({
  container: { flex: 1, backgroundColor: "#f5f5f5", alignItems: "center" },
  inner: { maxWidth: 460, width: "100%", flex: 1 },
  center: { padding: 24, alignItems: "center" },
  logo: { fontSize: 64, marginTop: 40, marginBottom: 8 },
  appName: { fontSize: 30, fontWeight: "800", color: "#c1622a", marginBottom: 4 },
  appSub: { fontSize: 14, color: "#6b7280", marginBottom: 32 },
  card: { backgroundColor: "#fff", borderRadius: 20, padding: 20, marginBottom: 16, width: "100%", shadowColor: "#c1622a", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.08, shadowRadius: 12, elevation: 4 },
  cardTitle: { fontSize: 18, fontWeight: "700", marginBottom: 16, color: "#1a1a1a" },
  label: { fontSize: 11, fontWeight: "700", color: "#6b7280", marginBottom: 6, letterSpacing: 1 },
  input: { borderWidth: 1.5, borderColor: "#e5e7eb", borderRadius: 10, padding: 12, fontSize: 15, marginBottom: 16, backgroundColor: "#f9fafb", color: "#1a1a1a" } as any,
  btn: { backgroundColor: "#c1622a", borderRadius: 12, padding: 16, alignItems: "center", marginTop: 4 },
  btnText: { color: "#fff", fontSize: 15, fontWeight: "700" },
  row: { flexDirection: "row", marginBottom: 12 },
  roleBtn: { flex: 1, borderWidth: 1.5, borderColor: "#e5e7eb", borderRadius: 10, padding: 12, marginHorizontal: 4, alignItems: "center" },
  roleBtnActive: { borderColor: "#c1622a", backgroundColor: "#fdf0e8" },
  roleBtnText: { fontSize: 13, color: "#6b7280", fontWeight: "600" },
  roleBtnTextActive: { color: "#c1622a" },
  dropBtn: { borderWidth: 1.5, borderColor: "#e5e7eb", borderRadius: 10, padding: 12, backgroundColor: "#f9fafb", flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  dropList: { borderWidth: 1.5, borderColor: "#e5e7eb", borderRadius: 10, backgroundColor: "#fff", marginTop: 4, marginBottom: 16, elevation: 4 },
  dropItem: { padding: 12, borderBottomWidth: 1, borderBottomColor: "#f3f4f6" },
  dropItemActive: { backgroundColor: "#fdf0e8" },
  header: { backgroundColor: "#c1622a", padding: 20, flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  headerSub: { fontSize: 12, color: "rgba(255,255,255,0.8)" },
  headerTitle: { fontSize: 20, fontWeight: "700", color: "#fff" },
  headerJob: { fontSize: 12, color: "rgba(255,255,255,0.7)" },
  signOutBtn: { backgroundColor: "rgba(255,255,255,0.2)", borderRadius: 8, padding: 10 },
  signOutText: { color: "#fff", fontSize: 13, fontWeight: "600" },
  entryRow: { flexDirection: "row", alignItems: "flex-start", paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: "#f3f4f6" },
  entryName: { fontSize: 16, fontWeight: "700", color: "#1a1a1a" },
  entryDate: { fontSize: 14, fontWeight: "600", color: "#1a1a1a" },
  entrySub: { fontSize: 13, color: "#6b7280", marginTop: 2 },
  entryMeta: { fontSize: 12, color: "#9ca3af", marginTop: 2 },
  badge: { borderRadius: 20, paddingHorizontal: 10, paddingVertical: 4, marginLeft: 8 },
  badgeText: { fontSize: 11, fontWeight: "700", textTransform: "capitalize" },
  statBox: { flex: 1, borderRadius: 14, padding: 14, alignItems: "center", marginHorizontal: 4 },
  statNum: { fontSize: 28, fontWeight: "800" },
  statLabel: { fontSize: 11, fontWeight: "600" },
  filterBtn: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, backgroundColor: "#fff", marginRight: 8 },
  filterBtnActive: { backgroundColor: "#c1622a" },
  filterText: { fontSize: 13, fontWeight: "600", color: "#6b7280" },
  filterTextActive: { color: "#fff" },
  modalOverlay: { flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" },
  modalCard: { backgroundColor: "#fff", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24 },
});
