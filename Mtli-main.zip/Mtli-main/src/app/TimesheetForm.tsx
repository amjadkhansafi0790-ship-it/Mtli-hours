import React, { useRef, useState } from "react";
import {
  ActivityIndicator, Alert,
  KeyboardAvoidingView, Platform,
  ScrollView,
  StyleSheet, Text, TextInput, TouchableOpacity, View
} from "react-native";

type Lunch = 0 | 30 | 60;

const PERIODS = (() => {
  const periods: { label: string; start: string; end: string }[] = [];
  const now = new Date();
  for (let m = -1; m <= 3; m++) {
    const month = new Date(now.getFullYear(), now.getMonth() + m, 1);
    const y = month.getFullYear();
    const mo = month.getMonth();
    const monthName = month.toLocaleString("default", { month: "long" });
    const lastDay = new Date(y, mo + 1, 0).getDate();
    const pad = (n: number) => String(n).padStart(2, "0");
    periods.push({ label: `${monthName} 1-14, ${y}`, start: `${y}-${pad(mo + 1)}-01`, end: `${y}-${pad(mo + 1)}-14` });
    periods.push({ label: `${monthName} 15-${lastDay}, ${y}`, start: `${y}-${pad(mo + 1)}-15`, end: `${y}-${pad(mo + 1)}-${lastDay}` });
  }
  return periods;
})();

const getDayName = (date: string) => {
  const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  return days[new Date(date).getDay()] || "";
};

const to24 = (time: string, ampm: string): string => {
  if (!time) return "";
  const parts = time.replace(/[^0-9:]/g, "").split(":");
  let hour = parseInt(parts[0]) || 0;
  const min = parts[1] ? parts[1].substring(0, 2).padEnd(2, "0") : "00";
  if (ampm === "AM" && hour === 12) hour = 0;
  if (ampm === "PM" && hour !== 12) hour += 12;
  return `${String(hour).padStart(2, "0")}:${min}`;
};

const calcHours = (start: string, end: string, lunch: Lunch): number => {
  if (!start || !end) return 0;
  const [sh, sm] = start.split(":").map(Number);
  const [eh, em] = end.split(":").map(Number);
  let total = (eh * 60 + em) - (sh * 60 + sm);
  if (total < 0) total += 24 * 60;
  return Math.round(Math.max(0, total - lunch) / 60 * 100) / 100;
};

function DropdownPicker({ label, options, value, onSelect, placeholder }: {
  label: string; options: string[]; value: string;
  onSelect: (v: string) => void; placeholder: string;
}) {
  const [open, setOpen] = useState(false);
  return (
    <View style={{ marginBottom: 16 }}>
      {label ? <Text style={s.label}>{label}</Text> : null}
      <TouchableOpacity style={s.dropBtn} onPress={() => setOpen(!open)}>
        <Text style={{ color: value ? "#1e1b4b" : "#c4c4c4", fontSize: 15 }}>{value || placeholder}</Text>
        <Text style={{ color: "#6b7280" }}>{open ? "▲" : "▼"}</Text>
      </TouchableOpacity>
      {open ? (
        <View style={s.dropList}>
          <ScrollView style={{ maxHeight: 200 }} nestedScrollEnabled={true} keyboardShouldPersistTaps="handled">
            {options.map((opt) => (
              <TouchableOpacity key={opt} style={[s.dropItem, value === opt && s.dropItemActive]} onPress={() => { onSelect(opt); setOpen(false); }}>
                <Text style={{ color: value === opt ? "#4f46e5" : "#1e1b4b", fontSize: 14 }}>{opt}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>
      ) : null}
    </View>
  );
}

interface Props {
  isSupervisor: boolean;
  profileName: string;
  profileTitle: string;
  profileCountry: string;
  profileId: string;
  onSubmit: (data: any) => void;
  onCancel: () => void;
}

export default function TimesheetForm({ isSupervisor, profileName, profileTitle, profileCountry, profileId, onSubmit, onCancel }: Props) {
  // Use refs for text inputs to prevent re-render focus loss
  const empNameRef = useRef(isSupervisor ? "" : profileName);
  const empJobTitleRef = useRef(isSupervisor ? "" : profileTitle);
  const projectRef = useRef("");
  const clientRef = useRef("");
  const jobLocationRef = useRef("");
  const dateRef = useRef(new Date().toISOString().split("T")[0]);
  const startTimeRef = useRef("");
  const endTimeRef = useRef("");
  const workDescRef = useRef("");
  const periodStartRef = useRef("");
  const periodEndRef = useRef("");

  // Only use state for things that need to trigger UI updates
  const [startAmPm, setStartAmPm] = useState<"AM" | "PM">("AM");
  const [endAmPm, setEndAmPm] = useState<"AM" | "PM">("PM");
  const [lunch, setLunch] = useState<Lunch>(0);
  const [loading, setLoading] = useState(false);
  const [selectedPeriod, setSelectedPeriod] = useState("");
  const [totalHours, setTotalHours] = useState(0);
  const [overtime, setOvertime] = useState(0);
  const [dayName, setDayName] = useState(getDayName(dateRef.current));

  const updateHours = (start: string, end: string, ap1: string, ap2: string, lunchVal: Lunch) => {
    const s24 = to24(start, ap1);
    const e24 = to24(end, ap2);
    const h = calcHours(s24, e24, lunchVal);
    setTotalHours(h);
    setOvertime(Math.max(0, h - 8));
  };

  const handleSubmit = async () => {
    const start24 = to24(startTimeRef.current, startAmPm);
    const end24 = to24(endTimeRef.current, endAmPm);
    if (!startTimeRef.current || !endTimeRef.current || !dateRef.current) {
      Alert.alert("Missing Info", "Please fill date, start and end time");
      return;
    }
    setLoading(true);
    await onSubmit({
      employee_id: profileId,
      employee_name: empNameRef.current || profileName,
      job_title: empJobTitleRef.current || profileTitle,
      project: projectRef.current,
      client: clientRef.current,
      job_location: jobLocationRef.current,
      date: dateRef.current,
      day: getDayName(dateRef.current),
      start_time: start24,
      end_time: end24,
      lunch_break: lunch,
      hours_worked: totalHours,
      overtime_hours: overtime,
      work_description: workDescRef.current,
      period_start: periodStartRef.current,
      period_end: periodEndRef.current,
      country: profileCountry,
      status: "pending"
    });
    setLoading(false);
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === "ios" ? "padding" : undefined}>
      <ScrollView contentContainerStyle={{ padding: 16 }} keyboardShouldPersistTaps="handled">
        <View style={s.card}>
          <Text style={s.cardTitle}>Submit Hours</Text>

          {isSupervisor ? (
            <View>
              <Text style={s.label}>EMPLOYEE NAME</Text>
              <TextInput
                style={s.input}
                placeholderTextColor="#c4c4c4"
                placeholder="Employee name"
                defaultValue={empNameRef.current}
                onChangeText={(t) => { empNameRef.current = t; }}
                autoCorrect={false}
                autoCapitalize="words"
              />
              <Text style={s.label}>EMPLOYEE JOB TITLE</Text>
              <TextInput
                style={s.input}
                placeholderTextColor="#c4c4c4"
                placeholder="Job title"
                defaultValue={empJobTitleRef.current}
                onChangeText={(t) => { empJobTitleRef.current = t; }}
                autoCorrect={false}
              />
            </View>
          ) : null}

          <Text style={s.label}>PAY PERIOD</Text>
          <DropdownPicker
            label=""
            options={PERIODS.map((p) => p.label)}
            value={selectedPeriod}
            onSelect={(label) => {
              const p = PERIODS.find((x) => x.label === label);
              if (p) {
                periodStartRef.current = p.start;
                periodEndRef.current = p.end;
                setSelectedPeriod(label);
              }
            }}
            placeholder="Select pay period..."
          />

          <Text style={s.label}>CUSTOM DATES (OPTIONAL)</Text>
          <View style={s.row}>
            <View style={{ flex: 1, marginRight: 8 }}>
              <Text style={s.label}>FROM</Text>
              <TextInput
                style={s.input}
                placeholderTextColor="#c4c4c4"
                placeholder="YYYY-MM-DD"
                defaultValue={periodStartRef.current}
                onChangeText={(t) => { periodStartRef.current = t; }}
              />
            </View>
            <View style={{ flex: 1, marginLeft: 8 }}>
              <Text style={s.label}>TO</Text>
              <TextInput
                style={s.input}
                placeholderTextColor="#c4c4c4"
                placeholder="YYYY-MM-DD"
                defaultValue={periodEndRef.current}
                onChangeText={(t) => { periodEndRef.current = t; }}
              />
            </View>
          </View>

          <Text style={s.label}>PROJECT</Text>
          <TextInput
            style={s.input}
            placeholderTextColor="#c4c4c4"
            placeholder="Project"
            defaultValue={projectRef.current}
            onChangeText={(t) => { projectRef.current = t; }}
            autoCorrect={false}
          />

          <Text style={s.label}>CLIENT</Text>
          <TextInput
            style={s.input}
            placeholderTextColor="#c4c4c4"
            placeholder="Client"
            defaultValue={clientRef.current}
            onChangeText={(t) => { clientRef.current = t; }}
            autoCorrect={false}
          />

          <Text style={s.label}>JOB LOCATION</Text>
          <TextInput
            style={s.input}
            placeholderTextColor="#c4c4c4"
            placeholder="Job Location"
            defaultValue={jobLocationRef.current}
            onChangeText={(t) => { jobLocationRef.current = t; }}
            autoCorrect={false}
          />

          <Text style={s.label}>DATE</Text>
          <TextInput
            style={s.input}
            placeholderTextColor="#c4c4c4"
            placeholder="YYYY-MM-DD"
            defaultValue={dateRef.current}
            onChangeText={(t) => { dateRef.current = t; setDayName(getDayName(t)); }}
          />
          {dayName ? <Text style={{ color: "#6b7280", fontSize: 13, marginTop: -12, marginBottom: 12 }}>{dayName}</Text> : null}

          <View style={s.row}>
            <View style={{ flex: 1, marginRight: 8 }}>
              <Text style={s.label}>START TIME</Text>
              <TextInput
                style={s.input}
                placeholderTextColor="#c4c4c4"
                placeholder="e.g. 7:00"
                keyboardType="numeric"
                defaultValue={startTimeRef.current}
                onChangeText={(t) => {
                  startTimeRef.current = t;
                  updateHours(t, endTimeRef.current, startAmPm, endAmPm, lunch);
                }}
              />
              <View style={s.ampmRow}>
                {(["AM", "PM"] as const).map((p) => (
                  <TouchableOpacity key={p} style={[s.ampmBtn, startAmPm === p && s.ampmActive]} onPress={() => {
                    setStartAmPm(p);
                    updateHours(startTimeRef.current, endTimeRef.current, p, endAmPm, lunch);
                  }}>
                    <Text style={[s.ampmText, startAmPm === p && s.ampmTextActive]}>{p}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
            <View style={{ flex: 1, marginLeft: 8 }}>
              <Text style={s.label}>END TIME</Text>
              <TextInput
                style={s.input}
                placeholderTextColor="#c4c4c4"
                placeholder="e.g. 5:00"
                keyboardType="numeric"
                defaultValue={endTimeRef.current}
                onChangeText={(t) => {
                  endTimeRef.current = t;
                  updateHours(startTimeRef.current, t, startAmPm, endAmPm, lunch);
                }}
              />
              <View style={s.ampmRow}>
                {(["AM", "PM"] as const).map((p) => (
                  <TouchableOpacity key={p} style={[s.ampmBtn, endAmPm === p && s.ampmActive]} onPress={() => {
                    setEndAmPm(p);
                    updateHours(startTimeRef.current, endTimeRef.current, startAmPm, p, lunch);
                  }}>
                    <Text style={[s.ampmText, endAmPm === p && s.ampmTextActive]}>{p}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          </View>

          {totalHours > 0 ? (
            <View style={s.hoursBox}>
              <Text style={s.hoursTotal}>Total Hours: {totalHours.toFixed(2)} hrs</Text>
              <Text style={s.hoursSub}>{startTimeRef.current} {startAmPm} to {endTimeRef.current} {endAmPm}</Text>
              {overtime > 0 ? <Text style={s.hoursOT}>Overtime: {overtime.toFixed(2)} hrs</Text> : null}
            </View>
          ) : null}

          <Text style={s.label}>LUNCH BREAK</Text>
          <View style={[s.row, { marginBottom: 16 }]}>
            {([0, 30, 60] as Lunch[]).map((l) => (
              <TouchableOpacity key={l} style={[s.lunchBtn, lunch === l && s.lunchActive]} onPress={() => {
                setLunch(l);
                updateHours(startTimeRef.current, endTimeRef.current, startAmPm, endAmPm, l);
              }}>
                <Text style={[s.lunchText, lunch === l && s.lunchTextActive]}>{l === 0 ? "No Lunch" : `${l} min`}</Text>
              </TouchableOpacity>
            ))}
          </View>

          <Text style={s.label}>WORK DESCRIPTION</Text>
          <TextInput
            style={[s.input, { height: 100 }]}
            placeholderTextColor="#c4c4c4"
            placeholder="Work Description"
            defaultValue={workDescRef.current}
            onChangeText={(t) => { workDescRef.current = t; }}
            multiline={true}
            autoCorrect={false}
          />

          <TouchableOpacity style={s.btn} onPress={handleSubmit} disabled={loading}>
            {loading ? <ActivityIndicator color="#fff" /> : <Text style={s.btnText}>Submit Hours</Text>}
          </TouchableOpacity>
          <TouchableOpacity style={[s.btn, { backgroundColor: "#6b7280", marginTop: 8 }]} onPress={onCancel}>
            <Text style={s.btnText}>Cancel</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  card: { backgroundColor: "#fff", borderRadius: 20, padding: 20, marginBottom: 16, width: "100%", shadowColor: "#4f46e5", shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.08, shadowRadius: 12, elevation: 4 },
  cardTitle: { fontSize: 18, fontWeight: "700", marginBottom: 16, color: "#1e1b4b" },
  label: { fontSize: 11, fontWeight: "700", color: "#6b7280", marginBottom: 6, letterSpacing: 1 },
  input: { borderWidth: 1.5, borderColor: "#e5e7eb", borderRadius: 10, padding: 12, fontSize: 15, marginBottom: 16, backgroundColor: "#f9fafb", color: "#1e1b4b" } as any,
  btn: { backgroundColor: "#4f46e5", borderRadius: 12, padding: 16, alignItems: "center", marginTop: 4 },
  btnText: { color: "#fff", fontSize: 15, fontWeight: "700" },
  row: { flexDirection: "row", marginBottom: 12 },
  dropBtn: { borderWidth: 1.5, borderColor: "#e5e7eb", borderRadius: 10, padding: 12, backgroundColor: "#f9fafb", flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  dropList: { borderWidth: 1.5, borderColor: "#e5e7eb", borderRadius: 10, backgroundColor: "#fff", marginTop: 4, marginBottom: 16, elevation: 4 },
  dropItem: { padding: 12, borderBottomWidth: 1, borderBottomColor: "#f3f4f6" },
  dropItemActive: { backgroundColor: "#eef2ff" },
  ampmRow: { flexDirection: "row", gap: 6, marginTop: -8, marginBottom: 12 },
  ampmBtn: { borderWidth: 1.5, borderColor: "#e5e7eb", borderRadius: 6, paddingHorizontal: 14, paddingVertical: 6, backgroundColor: "#f9fafb" },
  ampmActive: { borderColor: "#4f46e5", backgroundColor: "#4f46e5" },
  ampmText: { fontSize: 12, fontWeight: "700", color: "#6b7280" },
  ampmTextActive: { color: "#fff" },
  hoursBox: { backgroundColor: "#eef2ff", borderRadius: 10, padding: 12, marginBottom: 16 },
  hoursTotal: { color: "#4f46e5", fontWeight: "800", fontSize: 18, marginBottom: 2 },
  hoursSub: { color: "#4f46e5", fontSize: 12, marginBottom: 2 },
  hoursOT: { color: "#dc2626", fontWeight: "700", fontSize: 13, marginTop: 4 },
  lunchBtn: { flex: 1, borderWidth: 1.5, borderColor: "#e5e7eb", borderRadius: 10, padding: 10, marginHorizontal: 4, alignItems: "center" },
  lunchActive: { borderColor: "#4f46e5", backgroundColor: "#eef2ff" },
  lunchText: { fontSize: 12, color: "#6b7280", fontWeight: "600" },
  lunchTextActive: { color: "#4f46e5" },
});
